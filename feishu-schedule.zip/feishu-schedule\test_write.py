#!/usr/bin/env python3
"""
测试写入多维表格
"""
import json
import requests
from datetime import date, datetime
from config import APP_ID, APP_SECRET, BITABLE_APP_TOKEN, BITABLE_TABLE_ID

def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    return None

def add_record(token, record_data):
    """添加记录到多维表格"""
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{BITABLE_APP_TOKEN}/tables/{BITABLE_TABLE_ID}/records"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    data = {"fields": record_data}
    
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    return result

def main():
    print("正在获取 access_token...")
    token = get_tenant_access_token()
    if not token:
        print("获取 token 失败")
        return
    print("获取成功\n")
    
    # 测试数据
    today = date.today()
    date_ts = int(datetime(today.year, today.month, today.day).timestamp()) * 1000
    
    test_record = {
        "标题": "测试日程",
        "日期": date_ts,
        "时间": "15:00",
        "备注": "这是一条测试记录",
        "状态": "待完成",
        "来源": "手动测试"
    }
    
    print(f"正在写入测试数据: {test_record}")
    result = add_record(token, test_record)
    
    if result.get("code") == 0:
        print("\n[OK] 写入成功！")
        print(f"记录ID: {result['data']['record']['record_id']}")
    else:
        print(f"\n[FAIL] 写入失败: {result.get('msg')}")
        print(f"完整返回: {json.dumps(result, indent=2, ensure_ascii=False)}")

if __name__ == "__main__":
    main()
