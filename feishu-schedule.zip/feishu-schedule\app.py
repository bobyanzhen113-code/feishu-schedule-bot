"""
飞书 AI 日程助手 - 主程序
功能：
  1. 接收飞书消息事件
  2. AI 智能理解用户意图（对话/添加日程/查询日程）
  3. 自动添加日程到多维表格和日历
  4. 智能回复用户

启动方式：
    pip install -r requirements.txt
    python app.py
"""

import json
import hashlib
import hmac
import base64
import re
import logging
from datetime import datetime, date, timedelta
from flask import Flask, request, jsonify

import lark_oapi as lark
from lark_oapi.api.bitable.v1 import (
    CreateAppTableRecordRequest,
    AppTableRecord,
    SearchAppTableRecordRequest,
)
from lark_oapi.api.im.v1 import (
    ReplyMessageRequest,
    ReplyMessageRequestBody,
)

from config import (
    APP_ID, APP_SECRET,
    VERIFICATION_TOKEN, ENCRYPT_KEY,
    BITABLE_APP_TOKEN, BITABLE_TABLE_ID,
    PORT, SCHEDULE_KEYWORDS,
    AI_NAME, WELCOME_MESSAGE, HELP_MESSAGE,
)
from parser import parse_schedule_message, extract_schedule_intent
from ai_chat import AIChatHandler

# ── 日志配置 ─────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# ── 飞书 SDK 客户端 ──────────────────────────────────────────
feishu_client = lark.Client.builder() \
    .app_id(APP_ID) \
    .app_secret(APP_SECRET) \
    .log_level(lark.LogLevel.DEBUG) \
    .build()

# ── AI 对话处理器 ────────────────────────────────────────────
ai_handler = AIChatHandler()


# ═══════════════════════════════════════════════════════════
#  工具函数
# ═══════════════════════════════════════════════════════════

def decrypt_aes(encrypt_str: str, key: str) -> dict:
    """AES-CBC 解密飞书加密事件（当开启加密时使用）"""
    try:
        from Crypto.Cipher import AES
        key_bytes = hashlib.sha256(key.encode("utf-8")).digest()
        encrypt_bytes = base64.b64decode(encrypt_str)
        iv = encrypt_bytes[:16]
        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)
        decrypted = cipher.decrypt(encrypt_bytes[16:])
        # 去除 PKCS7 填充
        pad = decrypted[-1]
        decrypted = decrypted[:-pad]
        return json.loads(decrypted.decode("utf-8"))
    except Exception as e:
        logger.error(f"AES 解密失败: {e}")
        return {}


def get_event_body(raw: dict) -> dict:
    """统一处理加密/非加密事件体"""
    if "encrypt" in raw and ENCRYPT_KEY:
        return decrypt_aes(raw["encrypt"], ENCRYPT_KEY)
    return raw


def reply_to_user(message_id: str, text: str):
    """向用户回复确认消息"""
    try:
        req = ReplyMessageRequest.builder() \
            .message_id(message_id) \
            .request_body(
                ReplyMessageRequestBody.builder()
                .msg_type("text")
                .content(json.dumps({"text": text}))
                .build()
            ).build()
        feishu_client.im.v1.message.reply(req)
    except Exception as e:
        logger.warning(f"回复消息失败: {e}")


def write_to_bitable(record: dict) -> bool:
    """
    将日程记录写入飞书多维表格。
    record 字段对应多维表格列名，需与实际列名一致。
    """
    try:
        req = CreateAppTableRecordRequest.builder() \
            .app_token(BITABLE_APP_TOKEN) \
            .table_id(BITABLE_TABLE_ID) \
            .request_body(
                AppTableRecord.builder()
                .fields(record)
                .build()
            ).build()
        resp = feishu_client.bitable.v1.app_table_record.create(req)
        if not resp.success():
            logger.error(f"写入多维表格失败: code={resp.code}, msg={resp.msg}")
            return False
        logger.info(f"✅ 写入成功: {record}")
        return True
    except Exception as e:
        logger.error(f"写入多维表格异常: {e}")
        return False


def query_today_schedules() -> list:
    """查询今天的日程"""
    try:
        today = date.today()
        today_start = int(datetime(today.year, today.month, today.day).timestamp()) * 1000
        today_end = int(datetime(today.year, today.month, today.day, 23, 59, 59).timestamp()) * 1000
        
        # 这里简化处理，实际应该使用多维表格的筛选 API
        # 返回空列表表示需要后续实现
        return []
    except Exception as e:
        logger.error(f"查询日程失败: {e}")
        return []


def query_week_schedules() -> list:
    """查询本周的日程"""
    try:
        today = date.today()
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)
        return []
    except Exception as e:
        logger.error(f"查询日程失败: {e}")
        return []


# ═══════════════════════════════════════════════════════════
#  飞书事件路由
# ═══════════════════════════════════════════════════════════

@app.route("/webhook/feishu", methods=["POST"])
def feishu_webhook():
    raw = request.get_json(force=True, silent=True) or {}
    body = get_event_body(raw)

    # ── URL 验证（首次配置时飞书发送的握手请求）──
    if body.get("type") == "url_verification":
        challenge = body.get("challenge", "")
        logger.info(f"URL 验证成功，challenge={challenge}")
        return jsonify({"challenge": challenge})

    # ── Token 校验 ──
    token = body.get("token") or body.get("header", {}).get("token", "")
    if token != VERIFICATION_TOKEN:
        logger.warning("Verification token 不匹配，拒绝请求")
        return jsonify({"error": "invalid token"}), 403

    # ── 处理消息事件 ──
    event_type = body.get("header", {}).get("event_type", "")
    if event_type != "im.message.receive_v1":
        return jsonify({"code": 0})

    event = body.get("event", {})
    message = event.get("message", {})
    sender = event.get("sender", {}).get("sender_id", {}).get("open_id", "")
    msg_type = message.get("message_type", "")
    message_id = message.get("message_id", "")

    if msg_type != "text":
        reply_to_user(message_id, "🤖 目前只支持文字消息哦，请用文字和我交流~")
        return jsonify({"code": 0})

    # 解析消息内容
    try:
        content_str = message.get("content", "{}")
        content = json.loads(content_str)
        text = content.get("text", "").strip()
    except Exception:
        return jsonify({"code": 0})

    logger.info(f"收到消息: {text!r}")

    # ── AI 智能处理消息 ───────────────────────────────────────
    # 1. 检查是否是特殊指令
    lower_text = text.lower()
    
    # 帮助指令
    if lower_text in ["帮助", "help", "怎么用", "?", "？"]:
        reply_to_user(message_id, HELP_MESSAGE)
        return jsonify({"code": 0})
    
    # 问候语
    if lower_text in ["你好", "hi", "hello", "在吗", "在"]:
        reply_to_user(message_id, WELCOME_MESSAGE)
        return jsonify({"code": 0})
    
    # 查询今日日程
    if any(kw in lower_text for kw in ["今天日程", "今天安排", "今天有什么", "今日日程"]):
        schedules = query_today_schedules()
        if schedules:
            reply_text = "📅 今天的日程安排：\n\n"
            for i, s in enumerate(schedules[:5], 1):
                reply_text += f"{i}. {s.get('时间', '')} {s.get('标题', '')}\n"
        else:
            reply_text = "📭 今天暂时没有日程安排，可以好好休息一下~\n\n需要添加日程吗？直接告诉我：\n例如：明天下午3点开会"
        reply_to_user(message_id, reply_text)
        return jsonify({"code": 0})
    
    # 2. 判断是否是日程消息（带关键词或 AI 识别出日程意图）
    is_schedule = any(kw in text for kw in SCHEDULE_KEYWORDS)
    schedule_info = None
    
    if not is_schedule:
        # 尝试用 AI 理解日程意图
        schedule_info = extract_schedule_intent(text)
        if schedule_info:
            is_schedule = True
            logger.info(f"AI 识别出日程意图: {schedule_info}")
    
    if is_schedule:
        # 解析日程
        if schedule_info:
            # 使用 AI 提取的信息
            parsed = parse_schedule_message(f"【日程】{schedule_info}")
        else:
            parsed = parse_schedule_message(text)
        
        if not parsed:
            reply_to_user(message_id,
                "❌ 没理解你的日程安排，可以试试这样说：\n"
                "• 明天下午3点开会\n"
                "• 后天上午10点体检\n"
                "• 4月10日晚上8点和朋友吃饭\n"
                "\n或直接发送：帮助")
            return jsonify({"code": 0})

        # 写入多维表格
        success = write_to_bitable(parsed)
        if success:
            # 生成友好的确认回复
            date_str = datetime.fromtimestamp(parsed['日期'] // 1000).strftime('%m月%d日')
            reply_to_user(message_id,
                f"✅ 已为你添加日程！\n\n"
                f"📅 {date_str} {parsed.get('时间', '')}\n"
                f"📌 {parsed.get('标题', '')}\n"
                f"📝 {parsed.get('备注', '') or '无'}\n\n"
                f"💡 提示：到时间我会提醒你哦~")
        else:
            reply_to_user(message_id, "⚠️ 添加日程失败，请稍后重试或联系管理员。")
        
        return jsonify({"code": 0})
    
    # 3. 普通对话 - 使用 AI 回复
    ai_reply = ai_handler.chat(text, sender)
    reply_to_user(message_id, ai_reply)

    return jsonify({"code": 0})


# ═══════════════════════════════════════════════════════════
#  健康检查
# ═══════════════════════════════════════════════════════════

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.now().isoformat()})


if __name__ == "__main__":
    logger.info(f"🚀 {AI_NAME} 启动成功！监听端口 {PORT}")
    logger.info(f"   飞书机器人已就绪，可以开始对话和添加日程")
    app.run(host="0.0.0.0", port=PORT, debug=False)
