# ✅ 飞书机器人配置清单

## 你需要准备的信息

### 1. 飞书应用信息（在 https://open.feishu.cn/ 获取）

```
App ID: _________________________________
App Secret: _____________________________
```

**获取位置**：你的应用 → 凭证与基础信息

---

## 配置步骤清单

### □ 步骤 1：开启权限
访问：https://open.feishu.cn/app/你的AppID/permission

需要开启的权限：
- [ ] `im:message:send` - 发送消息
- [ ] `im:message.group_msg` - 接收群消息
- [ ] `im:message.p2p_msg` - 接收单聊消息
- [ ] `calendar:calendar` - 管理日历
- [ ] `calendar:calendar:readonly` - 读取日历

---

### □ 步骤 2：配置事件订阅
访问：https://open.feishu.cn/app/你的AppID/event-subscribe

- [ ] 开启"启用事件订阅"开关
- [ ] 请求地址：`https://你的服务地址/webhook/feishu`
- [ ] 验证令牌：留空
- [ ] 加密密钥：留空
- [ ] 保存并验证通过
- [ ] 添加事件：`im.message.receive_v1`

---

### □ 步骤 3：部署到 Render

1. 注册 Render：https://render.com/
2. [ ] 创建 Web Service
3. [ ] 连接 GitHub 仓库
4. [ ] 配置环境变量：
   ```
   APP_ID = 你的AppID
   APP_SECRET = 你的AppSecret
   ```
5. [ ] 等待部署完成
6. [ ] 复制服务地址（如 `https://xxx.onrender.com`）

---

### □ 步骤 4：发布应用
访问：https://open.feishu.cn/app/你的AppID/version

- [ ] 创建版本（1.0.0）
- [ ] 申请发布
- [ ] 等待审核通过

---

### □ 步骤 5：测试

在飞书中：
- [ ] 搜索应用名称
- [ ] 发送"你好" → 应该收到回复
- [ ] 发送"明天下午3点开会" → 应该添加日程
- [ ] 检查飞书日历是否出现新日程

---

## 完成后的效果

✅ 机器人 24 小时在线
✅ 支持自然语言对话
✅ 自动添加日程到飞书日历
✅ 支持查询今日日程

---

## 需要帮助？

如果在任何步骤遇到问题，告诉我：
1. 你在哪一步
2. 遇到了什么错误
3. 截图或错误信息

我会帮你解决！
