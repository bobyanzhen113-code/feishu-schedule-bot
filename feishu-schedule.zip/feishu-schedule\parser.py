"""
消息解析模块 - 将飞书自然语言消息解析为日程结构化数据

支持格式：
    【日程】2026-04-05 15:00 会议 - 项目周会，需要准备PPT
    【日程】明天下午3点 开会 - 注意带上方案
    【日程】2026-04-06 全天 生日
    【提醒】今晚8点 复习英语
    【任务】下午2点 完成报告

返回的字段名与飞书多维表格的列名对应：
    日期    → 日期类型字段
    时间    → 文本字段（如 "15:00"，或 "全天"）
    标题    → 文本字段
    备注    → 文本字段
    状态    → 单选字段（待完成 / 进行中 / 已完成）
    来源    → 文本字段（固定为 "飞书消息"）
"""

import re
from datetime import datetime, date, timedelta
import logging

logger = logging.getLogger(__name__)

# ── 中文数字映射 ─────────────────────────────────────────────
CN_NUM = {
    "零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
    "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
    "十一": 11, "十二": 12,
}
CN_TIME_PERIOD = {
    "凌晨": 0, "早上": 6, "早晨": 6, "今早": 6, "上午": 9,
    "中午": 12, "下午": 13, "傍晚": 17, "晚上": 18, "今晚": 18, "夜里": 20,
}


def cn_num_to_int(s: str) -> int | None:
    """将中文数字字符串转为整数（仅支持 0-12）"""
    s = s.strip()
    if s.isdigit():
        return int(s)
    return CN_NUM.get(s)


def parse_cn_time(text: str) -> tuple[int, int] | None:
    """
    从文本中解析中文时间表达，返回 (hour, minute) 或 None。
    示例：下午三点半 → (15, 30)
          早上10点 → (10, 0)
          20:30 → (20, 30)
    """
    # 标准 HH:MM 格式
    m = re.search(r"(\d{1,2})[:\：](\d{2})", text)
    if m:
        return int(m.group(1)), int(m.group(2))

    # 中文时间段 + 数字
    for period, base_hour in CN_TIME_PERIOD.items():
        pattern = rf"{period}([零一二两三四五六七八九十]+|\d+)点(半|([零一二两三四五六七八九十]+|\d+)分)?"
        m = re.search(pattern, text)
        if m:
            hour_raw = m.group(1)
            minute_raw = m.group(2)
            hour = cn_num_to_int(hour_raw)
            if hour is None:
                continue
            # 时间段偏移（如"下午1点"→13点，"下午12点"不变，"凌晨12点"→0点）
            if period in ("下午", "傍晚") and hour < 12:
                hour += 12
            elif period in ("晚上", "夜里", "今晚"):
                if hour < 12:
                    hour += 12
            elif period in ("凌晨",) and hour == 12:
                hour = 0
            elif period in ("上午", "早上", "早晨", "今早") and hour == 12:
                hour = 0

            if minute_raw == "半":
                minute = 30
            elif minute_raw and minute_raw not in ("半",):
                minute = cn_num_to_int(minute_raw) or 0
            else:
                minute = 0
            return hour, minute

    # 无时间段纯点钟（如"3点"）
    m = re.search(r"([零一二两三四五六七八九十]+|\d+)点(半|([零一二两三四五六七八九十]+|\d+)分)?", text)
    if m:
        hour = cn_num_to_int(m.group(1))
        minute_raw = m.group(2)
        if hour is not None:
            if minute_raw == "半":
                minute = 30
            elif minute_raw:
                minute = cn_num_to_int(minute_raw) or 0
            else:
                minute = 0
            return hour, minute

    return None


def parse_date(text: str, today: date) -> date | None:
    """
    从文本中解析日期，返回 date 对象或 None。
    支持：
      - 2026-04-05 / 2026/04/05
      - 04-05 / 4月5日
      - 今天 / 明天 / 后天
      - 这周X / 下周X
    """
    # YYYY-MM-DD 或 YYYY/MM/DD
    m = re.search(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", text)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass

    # MM-DD 或 M月D日
    m = re.search(r"(\d{1,2})[-月](\d{1,2})[日号]?", text)
    if m:
        try:
            return date(today.year, int(m.group(1)), int(m.group(2)))
        except ValueError:
            pass

    # 相对日期
    if "今天" in text or "今日" in text:
        return today
    if "明天" in text or "明日" in text:
        return today + timedelta(days=1)
    if "后天" in text:
        return today + timedelta(days=2)
    if "大后天" in text:
        return today + timedelta(days=3)

    # 周几
    weekday_map = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "天": 6, "日": 6}
    for prefix, delta in [("这周", 0), ("本周", 0), ("下周", 7)]:
        for cn, wd in weekday_map.items():
            if f"{prefix}{cn}" in text:
                diff = (wd - today.weekday()) % 7
                if diff == 0 and prefix.startswith("下"):
                    diff = 7
                return today + timedelta(days=diff)

    return None


def _remove_datetime_tokens(text: str) -> str:
    """
    从文本中删除日期、时间相关的 token，保留纯标题文字。
    顺序很重要：先删长模式，再删短模式，避免子串干扰。
    """
    patterns = [
        r"\d{4}[-/]\d{1,2}[-/]\d{1,2}",          # 2026-04-05（必须在 MM-DD 之前）
        r"\d{1,2}月\d{1,2}[日号]?",                # 4月5日
        # 带时间段的中文时间（今晚/凌晨/早上/上午/中午/下午/傍晚/晚上/夜里 + 数字 + 点）
        r"(?:今晚|今早|凌晨|早上|早晨|上午|中午|下午|傍晚|晚上|夜里)"
        r"[零一二两三四五六七八九十\d]+点(?:半|[零一二两三四五六七八九十\d]+分)?",
        # 不带时间段的中文时间
        r"[零一二两三四五六七八九十\d]+点(?:半|[零一二两三四五六七八九十\d]+分)?",
        r"\d{1,2}[:\：]\d{2}",                     # 15:00 / 9:30
        r"今天|今日|明天|明日|后天|大后天",          # 相对日期（今晚/今早已在上面处理）
        r"[这本下]周[一二三四五六日天]",             # 下周三
        r"全天|整天",                                # 全天
    ]
    result = text
    for p in patterns:
        result = re.sub(p, " ", result)
    return re.sub(r"\s+", " ", result).strip()


def parse_schedule_message(text: str) -> dict | None:
    """
    主解析函数。
    返回包含多维表格字段的 dict，或 None（解析失败）。
    """
    today = date.today()

    # 去掉关键词前缀
    clean = re.sub(r"^[【\[](日程|提醒|任务)[】\]]", "", text).strip()

    # 拆分 主体 和 备注
    # 分隔符必须是「空格-空格」或「空格—空格」，避免把日期中的横线误判
    parts = re.split(r"\s+[-—–]\s+", clean, maxsplit=1)
    main_part = parts[0].strip()
    note = parts[1].strip() if len(parts) > 1 else ""

    # 解析日期
    parsed_date = parse_date(main_part, today)
    if parsed_date is None:
        parsed_date = today

    # 解析时间
    is_allday = "全天" in main_part or "整天" in main_part
    time_str = "全天"
    if not is_allday:
        hm = parse_cn_time(main_part)
        if hm:
            time_str = f"{hm[0]:02d}:{hm[1]:02d}"

    # 提取标题：从主体中删除日期/时间 token
    title = _remove_datetime_tokens(main_part)

    if not title:
        logger.warning(f"标题为空，原始消息: {text!r}")
        return None

    # 日期转毫秒时间戳（飞书多维表格日期字段要求）
    date_ts = int(datetime(parsed_date.year, parsed_date.month, parsed_date.day).timestamp()) * 1000

    record = {
        "日期": date_ts,
        "时间": time_str,
        "标题": title,
        "备注": note,
        "状态": "待完成",
        "来源": "飞书消息",
    }
    logger.info(f"解析结果: {record}")
    return record


# ── 本地测试 ─────────────────────────────────────────────────
if __name__ == "__main__":
    test_cases = [
        "【日程】2026-04-05 15:00 会议 - 项目周会，需要准备PPT",
        "【日程】明天下午3点 开会 - 注意带上方案",
        "【日程】2026-04-06 全天 生日",
        "【提醒】今晚8点 复习英语",
        "【任务】下午两点半 完成报告",
        "【日程】下周三上午10点 体检",
        "【日程】4月10日 9:30 见客户",
    ]
    for msg in test_cases:
        result = parse_schedule_message(msg)
        print(f"输入: {msg}")
        print(f"输出: {result}")
        print()
