#!/usr/bin/env python3
"""
设置多维表格字段结构
"""
import json
import requests

# 你的应用凭证
APP_ID = "cli_a945efb68cb81bd1"
APP_SECRET = "UHbFeYQhrBTI3Vkhj0DbrgBQ21MPKiC0"
APP_TOKEN = "VfBHbgNK7a793Ps1b2OcQBF0nED"
TABLE_ID = "tblfczJupUq2GUHH"

def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    return None

def add_field(token, field_name, field_type, property_data=None):
    """添加字段"""
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{APP_TOKEN}/tables/{TABLE_ID}/fields"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    data = {
        "field_name": field_name,
        "type": field_type
    }
    if property_data:
        data["property"] = property_data
    
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    print(f"添加字段 [{field_name}]: code={result.get('code')}, msg={result.get('msg', 'OK')}")
    return result

def main():
    print("正在获取 access_token...")
    token = get_tenant_access_token()
    if not token:
        print("获取 token 失败")
        return
    print(f"获取成功\n")
    
    # 添加字段
    print("正在添加字段...")
    
    # 1. 标题（文本）
    add_field(token, "标题", 1)
    
    # 2. 日期（日期类型）
    add_field(token, "日期", 5)
    
    # 3. 时间（文本）
    add_field(token, "时间", 1)
    
    # 4. 备注（文本）
    add_field(token, "备注", 1)
    
    # 5. 状态（单选）
    add_field(token, "状态", 3, {
        "options": [
            {"name": "待完成", "color": 0},
            {"name": "进行中", "color": 1},
            {"name": "已完成", "color": 2}
        ]
    })
    
    # 6. 来源（文本）
    add_field(token, "来源", 1)
    
    print("\n[OK] 字段设置完成！")
    print(f"表格链接: https://xcnbgqor2g48.feishu.cn/base/{APP_TOKEN}")

if __name__ == "__main__":
    main()
