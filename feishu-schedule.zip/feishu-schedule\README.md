# 🤖 飞书 AI 日程助手

一个智能的飞书机器人，支持自然语言对话和日程管理。

## ✨ 功能特点

- 💬 **智能对话** - 像朋友一样聊天，支持问候、感谢、告别等自然交互
- 📅 **自然语言添加日程** - 无需固定格式，直接说"明天下午3点开会"
- 📋 **日程查询** - 询问"今天有什么安排"快速查看日程
- 🔔 **自动提醒** - 日程自动同步到飞书日历，到期提醒
- 📝 **多维表格记录** - 所有日程自动记录到飞书多维表格

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置飞书应用

1. 访问 [飞书开放平台](https://open.feishu.cn/)
2. 创建企业自建应用
3. 获取 **App ID** 和 **App Secret**，填入 `config.py`
4. 开启权限：
   - `im:chat:readonly` (读取群组信息)
   - `im:message:send` (发送消息)
   - `im:message.group_msg` (接收群消息)
   - `bitable:app` (多维表格管理)
   - `calendar:calendar:readonly` (读取日历)
   - `calendar:calendar` (管理日历)

### 3. 配置事件订阅

1. 在飞书开放平台 -> 事件订阅
2. 设置请求地址：`https://你的域名/webhook/feishu`
3. 订阅事件：`im.message.receive_v1` (接收消息)
4. 如果本地测试，可使用 [ngrok](https://ngrok.com/) 暴露本地端口：
   ```bash
   ngrok http 8080
   ```

### 4. 发布应用

1. 在飞书开放平台 -> 版本管理与发布
2. 创建版本并发布
3. 在飞书客户端搜索你的应用并添加

### 5. 启动服务

```bash
python app.py
```

服务将在 `http://0.0.0.0:8080` 启动

## 💬 使用示例

### 添加日程

直接发送自然语言：
```
明天下午3点开会
后天上午10点体检
4月10日晚上和朋友吃饭
下周三下午项目评审
```

或使用标准格式：
```
【日程】明天下午3点 开会 - 准备PPT
【提醒】今晚8点 健身
【任务】下周三上午10点 完成报告
```

### 查询日程

```
今天有什么安排
查看今日日程
```

### 日常对话

```
你好
谢谢
再见
帮助
```

## 📁 文件结构

```
feishu-schedule/
├── app.py              # 主程序 - Webhook 服务
├── ai_chat.py          # AI 对话处理
├── parser.py           # 消息解析模块
├── config.py           # 配置文件
├── calendar_api.py     # 日历 API 操作
├── requirements.txt    # Python 依赖
└── README.md           # 使用说明
```

## ⚙️ 配置说明

编辑 `config.py`：

```python
# 飞书应用凭证（必填）
APP_ID = "你的 App ID"
APP_SECRET = "你的 App Secret"

# 多维表格信息（必填）
BITABLE_APP_TOKEN = "多维表格 App Token"
BITABLE_TABLE_ID = "数据表 ID"

# 机器人个性化
AI_NAME = "小日程助手"  # 机器人名字
```

## 🛠️ 高级配置

### 修改监听端口

在 `config.py` 中修改：
```python
PORT = 8080  # 修改为你需要的端口
```

### 自定义欢迎消息

在 `config.py` 中修改 `WELCOME_MESSAGE`

## 🔧 故障排查

### 机器人不回复

1. 检查服务是否正常运行
2. 检查飞书事件订阅地址是否正确
3. 检查 App ID 和 App Secret 是否正确

### 日程添加失败

1. 检查多维表格权限是否开启
2. 检查 BITABLE_APP_TOKEN 和 BITABLE_TABLE_ID 是否正确
3. 查看日志获取详细错误信息

## 📄 许可证

MIT License
