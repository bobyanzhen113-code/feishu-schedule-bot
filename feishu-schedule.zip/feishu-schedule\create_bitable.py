#!/usr/bin/env python3
"""
用飞书 API 自动创建多维表格
"""
import json
import requests

# 你的应用凭证
APP_ID = "cli_a945efb68cb81bd1"
APP_SECRET = "UHbFeYQhrBTI3Vkhj0DbrgBQ21MPKiC0"

def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {
        "app_id": APP_ID,
        "app_secret": APP_SECRET
    }
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    else:
        print(f"获取 token 失败: {result}")
        return None

def create_bitable(token):
    """创建多维表格"""
    url = "https://open.feishu.cn/open-apis/bitable/v1/apps"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    data = {
        "name": "我的日程规划",
        "description": "飞书消息自动同步的日程表"
    }
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    # 写入文件避免终端编码问题
    with open("create_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"创建表格结果已保存到 create_result.json")
    print(f"code: {result.get('code')}, msg: {result.get('msg', 'N/A')}")
    return result

def main():
    print("正在获取 access_token...")
    token = get_tenant_access_token()
    if not token:
        return
    
    print(f"获取成功，token: {token[:20]}...")
    print("\n正在创建多维表格...")
    result = create_bitable(token)
    
    # 先检查是否有 data 字段
    if "data" not in result:
        print(f"\n[FAIL] 创建失败，返回中没有 data 字段")
        print(f"完整返回: {result}")
        return
    
    if result.get("code") == 0:
        app_token = result["data"]["app_token"]
        print(f"\n[OK] 创建成功！")
        print(f"app_token: {app_token}")
        print(f"表格链接: {result['data'].get('url', '请在飞书中查看')}")
    else:
        print(f"\n[FAIL] 创建失败，code: {result.get('code')}, msg: {result.get('msg')}")

if __name__ == "__main__":
    main()
