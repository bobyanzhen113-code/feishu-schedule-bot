"""
飞书多维表格初始化脚本
运行一次即可创建"日程规划"数据表及所有字段

使用方法：
    python setup_bitable.py
"""

import lark_oapi as lark
from lark_oapi.api.bitable.v1 import (
    CreateAppTableFieldRequest,
    AppTableField,
    CreateAppTableRequest,
    ReqTable,
)
from config import APP_ID, APP_SECRET, BITABLE_APP_TOKEN

client = lark.Client.builder() \
    .app_id(APP_ID) \
    .app_secret(APP_SECRET) \
    .build()

TABLE_NAME = "日程规划"

# 字段定义
# field_type 参考：1=文本 2=数字 3=单选 4=多选 5=日期 7=复选框 11=人员 15=URL
FIELDS = [
    {"field_name": "标题",   "type": 1},   # 文本
    {"field_name": "日期",   "type": 5},   # 日期
    {"field_name": "时间",   "type": 1},   # 文本
    {"field_name": "备注",   "type": 1},   # 文本
    {
        "field_name": "状态",
        "type": 3,   # 单选
        "property": {
            "options": [
                {"name": "待完成", "color": 1},
                {"name": "进行中", "color": 2},
                {"name": "已完成", "color": 3},
                {"name": "已取消", "color": 5},
            ]
        }
    },
    {"field_name": "来源", "type": 1},     # 文本
]


def create_table():
    """在多维表格中创建数据表"""
    req = CreateAppTableRequest.builder() \
        .app_token(BITABLE_APP_TOKEN) \
        .request_body(
            ReqTable.builder()
            .name(TABLE_NAME)
            .build()
        ).build()
    resp = client.bitable.v1.app_table.create(req)
    if not resp.success():
        print(f"❌ 创建数据表失败: {resp.msg}")
        return None
    table_id = resp.data.table_id
    print(f"✅ 数据表创建成功，table_id = {table_id}")
    return table_id


def add_fields(table_id: str):
    """向数据表添加字段"""
    for field_def in FIELDS:
        builder = AppTableField.builder() \
            .field_name(field_def["field_name"]) \
            .type(field_def["type"])
        if "property" in field_def:
            builder = builder.property(field_def["property"])

        req = CreateAppTableFieldRequest.builder() \
            .app_token(BITABLE_APP_TOKEN) \
            .table_id(table_id) \
            .request_body(builder.build()) \
            .build()
        resp = client.bitable.v1.app_table_field.create(req)
        if resp.success():
            print(f"  ✅ 字段 [{field_def['field_name']}] 添加成功")
        else:
            print(f"  ❌ 字段 [{field_def['field_name']}] 添加失败: {resp.msg}")


if __name__ == "__main__":
    print("=== 初始化飞书多维表格 ===")
    print(f"app_token: {BITABLE_APP_TOKEN}")
    table_id = create_table()
    if table_id:
        print(f"\n正在添加字段...")
        add_fields(table_id)
        print(f"\n🎉 完成！请将以下 table_id 填入 config.py：")
        print(f"BITABLE_TABLE_ID = \"{table_id}\"")
