# 🚀 一键部署到 Render（免费云平台）

## 准备工作

### 1. 注册账号
1. 访问 https://render.com/
2. 点击 **"Get Started for Free"**
3. 用 GitHub 账号登录（推荐，方便同步代码）

### 2. 上传代码到 GitHub
如果你还没有 GitHub 账号：
1. 访问 https://github.com/ 注册
2. 创建新仓库，名称如 `feishu-schedule-bot`
3. 上传代码：
   ```bash
   cd feishu-schedule
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/你的用户名/feishu-schedule-bot.git
   git push -u origin main
   ```

---

## 部署步骤

### 步骤 1：在 Render 创建服务

1. 登录 Render 后，点击 **"New +"** → **"Web Service"**
2. 选择 **"Build and deploy from a Git repository"**
3. 连接你的 GitHub 账号，选择 `feishu-schedule-bot` 仓库
4. 点击 **"Connect"**

### 步骤 2：配置服务

填写以下信息：

| 配置项 | 填写内容 |
|--------|----------|
| **Name** | `feishu-schedule-bot`（或你喜欢的名字）|
| **Region** | `Singapore`（亚洲用户选这个）|
| **Branch** | `main` |
| **Runtime** | `Python 3` |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1` |
| **Plan** | `Free`（免费）|

点击 **"Create Web Service"**

### 步骤 3：设置环境变量

服务创建后，点击 **"Environment"** 标签：

添加以下变量：

```
APP_ID = 你的飞书 App ID
APP_SECRET = 你的飞书 App Secret
VERIFICATION_TOKEN = （先留空）
ENCRYPT_KEY = （先留空）
BITABLE_APP_TOKEN = （可选，留空也行）
BITABLE_TABLE_ID = （可选，留空也行）
```

点击 **"Save Changes"**

### 步骤 4：等待部署完成

- 等待几分钟，直到看到 **"Your service is live"**
- 复制你的服务地址，例如：
  ```
  https://feishu-schedule-bot.onrender.com
  ```

---

## 配置飞书

### 1. 开启权限

访问 https://open.feishu.cn/ → 你的应用 → **权限管理**，添加：
- ✅ `im:message:send`
- ✅ `im:message.group_msg`
- ✅ `im:message.p2p_msg`
- ✅ `calendar:calendar`
- ✅ `calendar:calendar:readonly`

### 2. 配置事件订阅

1. 点击 **事件订阅** → 开启开关
2. **请求地址**：`https://你的服务地址/webhook/feishu`
   - 例如：`https://feishu-schedule-bot.onrender.com/webhook/feishu`
3. 点击 **"保存"**，应该显示 **"验证通过"**
4. 添加事件：`im.message.receive_v1`

### 3. 发布应用

1. 点击 **版本管理与发布** → **创建版本**
2. 版本号：`1.0.0`
3. 点击 **申请发布**

---

## 测试机器人

1. 在飞书搜索你的应用名称
2. 发送：**你好**
3. 机器人应该回复欢迎消息！
4. 发送：**明天下午3点开会**
5. 日程应该被添加到飞书日历！

---

## 常见问题

### Q: Render 免费版有什么限制？
**A**: 
- 15分钟无访问会自动休眠
- 首次访问需要等待几秒唤醒
- 每月 100GB 流量
- 对于个人使用完全够用

### Q: 如何更新代码？
**A**: 
1. 修改本地代码
2. `git add . && git commit -m "更新" && git push`
3. Render 会自动重新部署

### Q: 部署失败怎么办？
**A**: 
1. 点击 Render 的 **"Logs"** 查看错误日志
2. 检查环境变量是否设置正确
3. 确认 `requirements.txt` 包含所有依赖

---

## 完成！🎉

现在你的飞书机器人已经部署到云端，24小时在线，随时可以：
- 💬 和你对话
- 📅 添加日程到飞书日历
- 🔔 自动提醒

有问题随时问我！
