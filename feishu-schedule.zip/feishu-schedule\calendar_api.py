#!/usr/bin/env python3
"""
飞书日历 API 操作模块
"""
import json
import requests
from datetime import datetime, timedelta
from config import APP_ID, APP_SECRET


def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    return None


# 你的主日历ID
PRIMARY_CALENDAR_ID = "feishu.cn_16xDcL4KvPDmbaDhB7UNef@group.calendar.feishu.cn"


def create_calendar_event(token, title, start_time, end_time, description="", 
                         reminder_minutes=15, attendee_open_id=None):
    """
    创建日历事件
    
    Args:
        token: access_token
        title: 事件标题
        start_time: 开始时间 (datetime对象)
        end_time: 结束时间 (datetime对象)
        description: 事件描述
        reminder_minutes: 提前提醒时间（分钟）
        attendee_open_id: 参与者的open_id（可选）
    """
    url = f"https://open.feishu.cn/open-apis/calendar/v4/calendars/{PRIMARY_CALENDAR_ID}/events"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 构建事件数据
    event_data = {
        "summary": title,
        "description": description,
        "start_time": {
            "timestamp": str(int(start_time.timestamp())),
            "timezone": "Asia/Shanghai"
        },
        "end_time": {
            "timestamp": str(int(end_time.timestamp())),
            "timezone": "Asia/Shanghai"
        },
        "reminders": [
            {
                "minutes": reminder_minutes
            }
        ],
        "visibility": "default"
    }
    
    # 如果有参与者，添加到事件
    if attendee_open_id:
        event_data["attendees"] = [
            {
                "type": "open_id",
                "open_id": attendee_open_id
            }
        ]
    
    resp = requests.post(url, headers=headers, json=event_data)
    result = resp.json()
    return result


def add_schedule_to_calendar(title, date_ts, time_str, note="", reminder_minutes=15):
    """
    添加日程到飞书日历
    
    Args:
        title: 日程标题
        date_ts: 日期时间戳（毫秒）
        time_str: 时间字符串，如 "15:00" 或 "全天"
        note: 备注
        reminder_minutes: 提前提醒分钟数
    """
    token = get_tenant_access_token()
    if not token:
        print("[日历] 获取 token 失败")
        return None
    
    # 解析日期时间
    date_seconds = date_ts // 1000
    base_date = datetime.fromtimestamp(date_seconds)
    
    if time_str == "全天":
        # 全天事件
        start_time = base_date.replace(hour=0, minute=0, second=0)
        end_time = base_date.replace(hour=23, minute=59, second=59)
    else:
        # 解析具体时间
        try:
            hour, minute = map(int, time_str.split(":"))
            start_time = base_date.replace(hour=hour, minute=minute, second=0)
            # 默认持续1小时
            end_time = start_time + timedelta(hours=1)
        except:
            # 解析失败，默认全天
            start_time = base_date.replace(hour=0, minute=0, second=0)
            end_time = base_date.replace(hour=23, minute=59, second=59)
    
    # 创建日历事件
    result = create_calendar_event(
        token=token,
        title=title,
        start_time=start_time,
        end_time=end_time,
        description=note,
        reminder_minutes=reminder_minutes
    )
    
    if result.get("code") == 0:
        event_id = result["data"]["event"]["event_id"]
        print(f"[日历] 事件创建成功: {event_id}")
        return event_id
    else:
        print(f"[日历] 创建失败: {result.get('msg')}")
        return None


if __name__ == "__main__":
    # 测试
    from datetime import date
    today = date.today()
    date_ts = int(datetime(today.year, today.month, today.day).timestamp()) * 1000
    
    result = add_schedule_to_calendar(
        title="测试日历提醒",
        date_ts=date_ts,
        time_str="15:00",
        note="这是一条测试提醒",
        reminder_minutes=5
    )
    print(f"结果: {result}")
