"""
AI 对话处理模块
处理用户的日常对话，提供友好的交互体验
"""

import random
import re
from datetime import datetime, date

class AIChatHandler:
    """AI 对话处理器"""
    
    def __init__(self):
        self.user_context = {}  # 简单的用户上下文记忆
        
    def chat(self, message: str, user_id: str) -> str:
        """
        处理用户消息，返回 AI 回复
        """
        message = message.strip()
        lower_msg = message.lower()
        
        # 更新用户上下文
        if user_id not in self.user_context:
            self.user_context[user_id] = {"message_count": 0, "last_topic": None}
        self.user_context[user_id]["message_count"] += 1
        
        # 1. 感谢类
        if any(kw in lower_msg for kw in ["谢谢", "感谢", "thx", "thanks"]):
            return random.choice([
                "不客气！有需要随时找我 😊",
                "能帮到你我很开心！",
                "别客气，这是我的职责~",
                "随时为你服务！",
            ])
        
        # 2. 告别类
        if any(kw in lower_msg for kw in ["再见", "拜拜", "bye", "goodbye", "晚安"]):
            return random.choice([
                "再见！有需要随时找我 👋",
                "拜拜！祝你今天愉快~",
                "好的，随时等你回来！",
                "晚安！好好休息 😴",
            ])
        
        # 3. 时间相关
        if any(kw in lower_msg for kw in ["现在几点", "当前时间", "时间"]):
            now = datetime.now()
            return f"现在是 {now.strftime('%H:%M')}，日期是 {now.strftime('%Y年%m月%d日')}"
        
        # 4. 心情/状态询问
        if any(kw in lower_msg for kw in ["好吗", "怎么样", "如何", "状态"]):
            return random.choice([
                "我很好，随时准备帮你管理日程！📅",
                "状态满分！有什么日程需要添加吗？",
                "我很好呀，你呢？需要我帮你安排什么吗？",
            ])
        
        # 5. 能力询问
        if any(kw in lower_msg for kw in ["能做什么", "会什么", "功能", "能力"]):
            return """我可以帮你：

📅 **添加日程**
   • "明天下午3点开会"
   • "后天上午体检"
   • "4月10日晚上和朋友吃饭"

📋 **查询日程**
   • "今天有什么安排"
   • "查看今日日程"

💬 **日常对话**
   • 随时和我聊天
   • 询问时间、帮助等

发送"帮助"查看详细说明~"""
        
        # 6. 确认/否定
        if lower_msg in ["是", "是的", "对", "没错", "好", "好的", "行", "可以"]:
            return random.choice([
                "好的！",
                "明白！",
                "收到！",
                "OK！",
            ])
        
        if lower_msg in ["否", "不是", "不对", "不用", "算了", "不要"]:
            return random.choice([
                "好的，没问题。",
                "明白，那先不处理。",
                "好的，有其他需要随时告诉我。",
            ])
        
        # 7. 默认回复 - 尝试理解用户可能想添加日程
        return self._default_reply(message)
    
    def _default_reply(self, message: str) -> str:
        """默认回复，同时提示如何添加日程"""
        
        # 检查是否包含时间相关词汇
        time_keywords = ["点", "分", "号", "日", "明天", "后天", "今天", "上午", "下午", "晚上", "早上"]
        has_time = any(kw in message for kw in time_keywords)
        
        if has_time:
            return f"""我注意到你的消息里提到了时间，是想添加日程吗？

你可以这样说：
• "【日程】{message}"

或者直接告诉我：
• "明天下午3点开会"
• "后天上午10点体检"

发送"帮助"查看更多用法 😊"""
        
        return random.choice([
            "收到！如果需要添加日程，直接告诉我就行，比如：\n• 明天下午3点开会\n• 后天上午体检",
            "我在听~ 需要添加日程的话，可以说：\n• 明天下午3点开会\n• 4月10日晚上吃饭",
            "明白了！需要我帮你记录什么日程吗？\n例如：明天下午3点开会",
            "好的！随时告诉我你的日程安排，我会帮你记录下来~",
            "收到！发送"帮助"可以查看我能做什么 😊",
        ])


# 简单的意图识别函数
def extract_schedule_intent(text: str) -> str | None:
    """
    从普通对话中提取日程意图
    返回格式化后的日程字符串，或 None
    
    示例：
        "明天下午3点要开会" -> "明天下午3点 开会"
        "提醒我后天上午体检" -> "后天上午 体检"
        "4月10号晚上和朋友吃饭" -> "4月10号晚上 和朋友吃饭"
    """
    text = text.strip()
    
    # 已经包含关键词的，不重复处理
    if any(kw in text for kw in ["【日程】", "【提醒】", "【任务】"]):
        return None
    
    # 时间模式匹配
    time_patterns = [
        # 明天/后天/今天 + 时间段 + 事件
        r"(明天|后天|今天|大后天)(上午|下午|晚上|早上|中午|凌晨)?(\d{1,2})?[点:：]?(\d{1,2})?[分]?\s*[要提醒我]?\s*[去]?(.*)",
        # 具体日期
        r"(\d{1,2})[月/-](\d{1,2})[日号]?\s*(上午|下午|晚上|早上|中午)?(\d{1,2})?[点:：]?(\d{1,2})?[分]?\s*[要提醒我]?\s*[去]?(.*)",
        # 周几
        r"(这|下)?周([一二三四五六日天])\s*(上午|下午|晚上|早上|中午)?(\d{1,2})?[点:：]?(\d{1,2})?[分]?\s*[要提醒我]?\s*[去]?(.*)",
    ]
    
    # 检查是否包含时间和事件关键词
    time_keywords = ["点", "分", "明天", "后天", "今天", "上午", "下午", "晚上", "早上", "中午", "号", "日"]
    action_keywords = ["开会", "见面", "吃饭", "聚餐", "体检", "看病", "买药", "取快递", "交", "做", "去", "来", "提醒", "记得"]
    
    has_time = any(kw in text for kw in time_keywords)
    has_action = any(kw in text for kw in action_keywords)
    
    # 如果既没有明显的时间也没有动作，可能不是日程
    if not has_time:
        return None
    
    # 尝试提取日程信息
    # 移除一些常见的前缀词
    clean_text = text
    prefixes = ["提醒我", "记得", "我要", "我想", "帮我", "请", "麻烦", "需要"]
    for prefix in prefixes:
        if clean_text.startswith(prefix):
            clean_text = clean_text[len(prefix):].strip()
    
    # 如果清理后还有内容，且包含时间信息，认为是日程意图
    if clean_text and len(clean_text) > 3:
        # 简单判断：是否包含数字或时间词
        has_time_indicator = bool(re.search(r'\d|明天|后天|今天|上午|下午|晚上|早上|中午', clean_text))
        if has_time_indicator:
            return clean_text
    
    return None
