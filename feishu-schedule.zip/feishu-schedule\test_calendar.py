#!/usr/bin/env python3
"""
测试飞书日历 API
"""
import requests
from config import APP_ID, APP_SECRET


def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    return None


def get_calendar_list(token):
    """获取日历列表"""
    url = "https://open.feishu.cn/open-apis/calendar/v4/calendars"
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.get(url, headers=headers)
    return resp.json()


def get_primary_calendar(token):
    """获取主日历"""
    url = "https://open.feishu.cn/open-apis/calendar/v4/calendars/primary"
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.get(url, headers=headers)
    return resp.json()


def main():
    token = get_tenant_access_token()
    if not token:
        print("获取 token 失败")
        return
    
    print("获取日历列表...")
    result = get_calendar_list(token)
    print(f"结果: {result}")
    
    print("\n获取主日历...")
    result2 = get_primary_calendar(token)
    print(f"结果: {result2}")


if __name__ == "__main__":
    main()
