#!/usr/bin/env python3
"""
添加日程到飞书多维表格 + 日历提醒
用法: python add_schedule.py "【日程】明天下午3点 开会 - 准备PPT"
"""
import sys
import json
import requests
from datetime import date, datetime
from config import APP_ID, APP_SECRET, BITABLE_APP_TOKEN, BITABLE_TABLE_ID
from parser import parse_schedule_message
from calendar_api import add_schedule_to_calendar


def get_tenant_access_token():
    """获取 tenant_access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    if result.get("code") == 0:
        return result["tenant_access_token"]
    return None


def add_record(token, record_data):
    """添加记录到多维表格"""
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{BITABLE_APP_TOKEN}/tables/{BITABLE_TABLE_ID}/records"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    data = {"fields": record_data}
    
    resp = requests.post(url, headers=headers, json=data)
    result = resp.json()
    return result


def main():
    if len(sys.argv) < 2:
        print("用法: python add_schedule.py \"【日程】明天下午3点 开会 - 准备PPT\"")
        print("\n支持的消息格式:")
        print("  【日程】明天下午3点 开会 - 准备PPT")
        print("  【提醒】今晚8点 健身")
        print("  【任务】下周三上午10点 体检")
        return
    
    message = sys.argv[1]
    print(f"收到消息: {message}\n")
    
    # 解析消息
    record = parse_schedule_message(message)
    if not record:
        print("[FAIL] 消息解析失败，请检查格式")
        return
    
    print(f"解析结果:")
    print(f"  标题: {record['标题']}")
    print(f"  日期: {record['时间']}")
    print(f"  时间: {record['时间']}")
    print(f"  备注: {record['备注']}")
    print(f"  状态: {record['状态']}\n")
    
    # 获取 token
    print("正在连接飞书...")
    token = get_tenant_access_token()
    if not token:
        print("[FAIL] 连接失败，请检查 App ID 和 App Secret")
        return
    
    # 写入多维表格
    print("正在写入多维表格...")
    result = add_record(token, record)
    
    if result.get("code") == 0:
        print("\n[OK] 多维表格写入成功！")
        print(f"记录ID: {result['data']['record']['record_id']}")
        
        # 同时添加到日历提醒
        print("\n正在创建日历提醒...")
        calendar_event_id = add_schedule_to_calendar(
            title=record['标题'],
            date_ts=record['日期'],
            time_str=record['时间'],
            note=record['备注'],
            reminder_minutes=15  # 提前15分钟提醒
        )
        
        if calendar_event_id:
            print("\n[OK] 日历提醒创建成功！")
            print(f"将在日程开始前15分钟提醒你")
        else:
            print("\n[WARN] 日历提醒创建失败，但多维表格已写入")
        
        print(f"\n表格链接: https://xcnbgqor2g48.feishu.cn/base/{BITABLE_APP_TOKEN}")
    else:
        print(f"\n[FAIL] 添加失败: {result.get('msg')}")


if __name__ == "__main__":
    main()
